import java.util.*;
class Ntimes{
	public static void main(String args[]){
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter a Number ");
    int n = sc.nextInt();
    int count = 0;
    for (int a = 1; a<=n; a++)
    {
     count = a+count;  	
     
     
     
    }
    System.out.print("Sum of Numbers = "+count);
    
    
    
    
	}
}