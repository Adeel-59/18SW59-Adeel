class StaricTask1{
	public static void main(String args[]){

		for (int a=0; a<=5 ; a++)
		{
			for (int b=0; b <= a ; b++)
			{
				System.out.print("*");
        
            }//end of inner loop
                System.out.println("");


		}//end of outer loop
		





	                                      }//end of main
              }//end of class