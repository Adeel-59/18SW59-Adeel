class StaricTask3{
	public static void main (String args[])
	{
		
    for(int a = 0; a<6; a++)
    {
    	for (int b = 6; b>a; b--)
        {
        	System.out.print(" ");



        }
        for (int c = 0; c <= a; c++)
        {
        	System.out.print("* ");



        }
       System.out.println("");






    }//end of FOR1




	}//end of main


}//end of class