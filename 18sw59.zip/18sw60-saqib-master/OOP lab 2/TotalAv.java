class TotalAv{
	public static void main(String[] args){
		float a=36.7f;
		float b=7.45f;
		float c=63.7f;
		float d=654.6f;
		float e=36.22f;
		float Total=a+b+c+d+e;
		float avg=(a+b+c+d+e)/5;
		    System.out.println("Total sum is ="+Total);
		    System.out.println("Average is ="+avg);
	}
}