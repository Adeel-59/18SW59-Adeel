class RTimePr{
	public static void main(String[] args){
		String name=args[0];
		String RollNo=args[1];
		System.out.println("Name ="+name);
		System.out.println("Roll No ="+RollNo);

	}
}