class Opt{
	public static void main(String args[]){
    int a = 3;
    int b = 5;
    if (a==b)
    System.out.print("A and B are equal");
    if(a<b)
    System.out.print("A is Less than B");
    if (a>b)
    System.out.print("A is Greater than B");

}





}