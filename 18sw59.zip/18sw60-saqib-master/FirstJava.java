class FirstJava
{
	public static void main(String [] args){
		
		String nAme;
		int marks;
		float per;
		char grade;
	    String status;
        byte age;
        long year;
        double stdnts;


		nAme="Saqib";
		marks=83;
        per= 93.4f;
        grade='A';
		status= "pass";
		age= 20;

		year= 2019;
		stdnts= 30;
		//true== "pass";
		System.out.println("Name =" + nAme+ "\nMarks = "+ marks+"\nPercentage ="+ per+"%"+ "\nGrade = "+grade+"\nStatus ="+status+"\nAge ="+age );
		System.out.println("Year ="+year+"\nTotal Students ="+stdnts);
	}
}